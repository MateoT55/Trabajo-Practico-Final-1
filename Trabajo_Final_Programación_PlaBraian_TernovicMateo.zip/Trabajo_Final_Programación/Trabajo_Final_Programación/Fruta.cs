﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Final_Programación
{
    public class Fruta: Ingrediente
    {


        public Fruta()
        {
            this.nombre = string.Empty;
            this.cantidad = 0;
            this.calorias = 0;
            this.proteina = 0;
            this.carbohidratos = 0;
            this.grasas = 0;
            this.esVegano = false;
            this.aptoCeliaco = false;
        }

        public Fruta(string nombre, double cantidad, double calorias, double proteina, double carbohidratos, double grasas, bool esVegano, bool aptoCeliaco)
        {
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.calorias = calorias;
            this.proteina = proteina;
            this.carbohidratos = carbohidratos;
            this.grasas = grasas;
            this.esVegano = esVegano;
            this.aptoCeliaco = aptoCeliaco;
        }





    }
}
